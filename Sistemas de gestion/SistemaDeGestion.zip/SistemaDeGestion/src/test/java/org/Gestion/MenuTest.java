package org.Gestion;

import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Arrays;
import static org.junit.jupiter.api.Assertions.*;

public class MenuTest {

    Menu menu = new Menu(1,"Comidas");

    @Test
    public void testagregarProducto(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        Producto p2 = new Producto(2,"Pizza","Pizza de peperoni",30000,"Comida rápida",20);

        menu.agregarProducto(p1);
        menu.agregarProducto(p2);

        int resultadoEsperado = 2;
        int resultadoActual = menu.getListaProductos().size();

        assertEquals(resultadoEsperado,resultadoActual);
        assertTrue(menu.getListaProductos().contains(p1));
        assertNotEquals(3,resultadoActual);
    }

    @Test
    public void testagregarProductoDuplicado(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        menu.agregarProducto(p1);
        menu.agregarProducto(p1);

        int resultadoEsperado = 1;
        int resultadoActual = menu.getListaProductos().size();

        assertEquals(resultadoEsperado,resultadoActual);
        assertTrue(menu.getListaProductos().contains(p1));
        assertNotEquals(2,resultadoActual);
    }

    @Test
    public void testeliminarProducto(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        Producto p2 = new Producto(2,"Pizza","Pizza de peperoni",30000,"Comida rápida",20);

        menu.agregarProducto(p1);
        menu.agregarProducto(p2);

        menu.eliminarProducto(p1);

        int resultadoEsperado = 1;
        int resultadoActual = menu.getListaProductos().size();

        assertEquals(resultadoEsperado,resultadoActual);
        assertFalse(menu.getListaProductos().contains(p1));
        assertNotEquals(2,resultadoActual);
    }

    @Test
    public void testeliminarProductoInexistente(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        Producto p2 = new Producto(2,"Pizza","Pizza de peperoni",30000,"Comida rápida",20);

        menu.agregarProducto(p1);
        menu.eliminarProducto(p2);

        int resultadoEsperado = 1;
        int resultadoActual = menu.getListaProductos().size();

        assertEquals(resultadoEsperado,resultadoActual);
        assertTrue(menu.getListaProductos().contains(p1));
    }

    @Test
    public void testgetProductosPorCategoria(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        Producto p2 = new Producto(2,"Pizza","Pizza de peperoni",30000,"Comida rápida",20);
        Producto p3 = new Producto(3,"Café","Café americano",8000,"Bebida",5);

        menu.agregarProducto(p1);
        menu.agregarProducto(p2);
        menu.agregarProducto(p3);

        List<Producto> resultadoEsperado = Arrays.asList(p1,p2);
        List<Producto> resultadoActual = menu.getProductosPorCategoria("Comida rápida");

        assertEquals(resultadoEsperado,resultadoActual);
        assertNotNull(resultadoActual);
        assertNotEquals(3,resultadoActual.size());
    }

    @Test
    public void testgetProductosPorCategoriaVacia(){
        Producto p1 = new Producto(1,"Café","Café americano",8000,"Bebida",5);
        menu.agregarProducto(p1);

        List<Producto> resultadoEsperado = Arrays.asList();
        List<Producto> resultadoActual = menu.getProductosPorCategoria("Postres");

        assertEquals(resultadoEsperado,resultadoActual);
        assertTrue(resultadoActual.isEmpty());
        assertNotNull(resultadoActual);
    }

    @Test
    public void testbuscarProductoPorId(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        Producto p2 = new Producto(2,"Pizza","Pizza de peperoni",30000,"Comida rápida",20);

        menu.agregarProducto(p1);
        menu.agregarProducto(p2);

        Producto resultadoEsperado = p2;
        Producto resultadoActual = menu.buscarProductoPorId(2);

        assertEquals(resultadoEsperado,resultadoActual);
        assertNotNull(resultadoActual);
        assertNull(menu.buscarProductoPorId(10));
    }

    @Test
    public void testgetListaProductos(){
        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        menu.agregarProducto(p1);

        List<Producto> resultadoEsperado = Arrays.asList(p1);
        List<Producto> resultadoActual = menu.getListaProductos();

        assertEquals(resultadoEsperado,resultadoActual);
        assertNotNull(resultadoActual);
        assertFalse(resultadoActual.isEmpty());
    }

    @Test
    public void testgetIdMenu(){
        int resultadoEsperado = 1;
        int resultadoActual = menu.getIdMenu();

        assertEquals(resultadoEsperado,resultadoActual);
        assertNotEquals(2,resultadoActual);
    }

    @Test
    public void testgetNombre(){
        String resultadoEsperado = "Comidas";
        String resultadoActual = menu.getNombre();

        assertEquals(resultadoEsperado,resultadoActual);
        assertNotNull(resultadoActual);
        assertNotEquals("Postres",resultadoActual);
    }

    @Test
    public void testsetNombre(){
        menu.setNombre("Desayunos");

        String resultadoEsperado = "Desayunos";
        String resultadoActual = menu.getNombre();

        assertEquals(resultadoEsperado,resultadoActual);
        assertNotEquals("Comidas",resultadoActual);
        assertNotNull(resultadoActual);
    }

    @Test
    public void testmostrarMenuVacio(){
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        System.setOut(new PrintStream(salida));

        menu.mostrarMenu();
        String resultadoActual = salida.toString();

        assertTrue(resultadoActual.contains("MENÚ: Comidas"));
        assertTrue(resultadoActual.contains("No hay productos disponibles"));
        assertNotNull(resultadoActual);
    }

    @Test
    public void testmostrarMenuConProductos(){
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        System.setOut(new PrintStream(salida));

        Producto p1 = new Producto(1,"Hamburguesa","Pan artesanal con carne",25000,"Comida rápida",15);
        Producto p2 = new Producto(2,"Pizza","Pizza de peperoni",30000,"Comida rápida",20);

        menu.agregarProducto(p1);
        menu.agregarProducto(p2);

        menu.mostrarMenu();
        String resultadoActual = salida.toString();

        assertTrue(resultadoActual.contains("MENÚ: Comidas"));
        assertTrue(resultadoActual.contains("Hamburguesa"));
        assertTrue(resultadoActual.contains("Pizza"));
        assertNotNull(resultadoActual);
    }

    @Test
    public void testtoString(){
        Producto p1 = new Producto(1,"Café","Café americano",5000,"Bebida",5);
        menu.agregarProducto(p1);

        String resultadoEsperado = "Menú: Comidas (ID: 1) - 1 productos";
        String resultadoActual = menu.toString();

        assertEquals(resultadoEsperado,resultadoActual);
        assertTrue(resultadoActual.contains("Comidas"));
        assertNotNull(resultadoActual);
    }
}
