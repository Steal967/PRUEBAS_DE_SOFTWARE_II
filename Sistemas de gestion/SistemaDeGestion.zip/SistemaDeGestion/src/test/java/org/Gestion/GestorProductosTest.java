package org.Gestion;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

public class GestorProductosTest {

    private GestorProductos gestor;
    private Producto productoExtra;

    @BeforeEach
    public void setUp() {
        gestor = new GestorProductos();
        productoExtra = new Producto(99, "Empanada", "De carne", 5000, "Colombiana", 5);
    }

    @Test
    public void testAgregarProducto() {
        gestor.agregarProducto(productoExtra);
        Producto resultadoEsperado = productoExtra;
        Producto resultadoActual = gestor.obtenerProducto(99);
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testEliminarProductoExistente() {
        gestor.agregarProducto(productoExtra);
        boolean resultadoEsperado = true;
        boolean resultadoActual = gestor.eliminarProducto(99);
        assertEquals(resultadoEsperado, resultadoActual);
        assertNull(gestor.obtenerProducto(99));
    }

    @Test
    public void testEliminarProductoInexistente() {
        boolean resultadoEsperado = false;
        boolean resultadoActual = gestor.eliminarProducto(500);
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testObtenerProductoExistente() {
        Producto resultadoEsperado = gestor.obtenerProducto(1);
        Producto resultadoActual = gestor.obtenerProducto(1);
        assertEquals(resultadoEsperado.getNombre(), resultadoActual.getNombre());
    }

    @Test
    public void testListarTodos() {
        List<Producto> resultadoActual = gestor.listarTodos();
        assertTrue(resultadoActual.size() >= 9);
    }

    @Test
    public void testListarPorCategoria() {
        List<Producto> resultadoEsperado = gestor.listarPorCategoria("Italiana");
        boolean resultadoActual = resultadoEsperado.stream().allMatch(p -> p.getCategoria().equals("Italiana"));
        assertTrue(resultadoActual);
    }

    @Test
    public void testListarPorCategoriaInexistente() {
        List<Producto> resultadoEsperado = gestor.listarPorCategoria("Japonesa");
        int resultadoActual = resultadoEsperado.size();
        assertEquals(0, resultadoActual);
    }

    @Test
    public void testAplicarPromocion() {
        gestor.aplicarPromocion("Pizza Margherita", 15.0);
        double resultadoEsperado = 15.0;
        double resultadoActual = gestor.getPromociones().get("Pizza Margherita");
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testHayProductosVerdadero() {
        boolean resultadoEsperado = true;
        boolean resultadoActual = gestor.hayProductos();
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testHayProductosFalso() {
        GestorProductos gestorVacio = new GestorProductos();
        for (Producto p : gestorVacio.listarTodos()) {
            gestorVacio.eliminarProducto(p.getIdProducto());
        }
        boolean resultadoEsperado = false;
        boolean resultadoActual = gestorVacio.hayProductos();
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testGetPromociones() {
        gestor.aplicarPromocion("Ajiaco", 10.0);
        Map<String, Double> resultadoEsperado = gestor.getPromociones();
        assertTrue(resultadoEsperado.containsKey("Ajiaco"));
    }

    @Test
    public void testCrearMenu() {
        Menu menu = gestor.crearMenu("Menú Especial");
        String resultadoEsperado = "Menú Especial";
        String resultadoActual = menu.getNombre();
        assertEquals(resultadoEsperado, resultadoActual);
        assertNotNull(gestor.obtenerMenu(menu.getIdMenu()));
    }

    @Test
    public void testObtenerMenuExistente() {
        Menu resultadoEsperado = gestor.obtenerMenu(1);
        Menu resultadoActual = gestor.obtenerMenu(1);
        assertEquals(resultadoEsperado.getNombre(), resultadoActual.getNombre());
    }

    @Test
    public void testListarMenus() {
        List<Menu> resultadoActual = gestor.listarMenus();
        assertTrue(resultadoActual.size() >= 3);
    }

    @Test
    public void testAgregarProductoAMenu() {
        gestor.agregarProducto(productoExtra);
        Menu menu = gestor.crearMenu("Menú Prueba");
        gestor.agregarProductoAMenu(menu.getIdMenu(), productoExtra.getIdProducto());
        boolean resultadoEsperado = true;
        boolean resultadoActual = menu.getListaProductos().contains(productoExtra);
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testAgregarProductoAMenuInexistente() {
        gestor.agregarProducto(productoExtra);
        gestor.agregarProductoAMenu(999, productoExtra.getIdProducto());
        Menu menuInexistente = gestor.obtenerMenu(999);
        assertNull(menuInexistente);
    }

    @Test
    public void testEliminarProductoDeMenu() {
        gestor.agregarProducto(productoExtra);
        Menu menu = gestor.crearMenu("Menú Test");
        gestor.agregarProductoAMenu(menu.getIdMenu(), productoExtra.getIdProducto());
        gestor.eliminarProductoDeMenu(menu.getIdMenu(), productoExtra.getIdProducto());
        boolean resultadoEsperado = false;
        boolean resultadoActual = menu.getListaProductos().contains(productoExtra);
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    public void testEliminarProductoDeMenuInexistente() {
        gestor.agregarProducto(productoExtra);
        gestor.eliminarProductoDeMenu(999, productoExtra.getIdProducto());
        Menu menuInexistente = gestor.obtenerMenu(999);
        assertNull(menuInexistente);
    }

    @Test
    public void testMostrarMenuExistente() {
        assertDoesNotThrow(() -> gestor.mostrarMenu(1));
    }

    @Test
    public void testMostrarMenuInexistente() {
        assertDoesNotThrow(() -> gestor.mostrarMenu(999));
    }

    @Test
    public void testMostrarTodosLosMenus() {

        assertDoesNotThrow(() -> gestor.mostrarTodosLosMenus());

        GestorProductos gestorSinMenus = new GestorProductos();
        try {
            java.lang.reflect.Field fieldMenus = GestorProductos.class.getDeclaredField("menus");
            fieldMenus.setAccessible(true);
            Map<Integer, Menu> mapaMenus = (Map<Integer, Menu>) fieldMenus.get(gestorSinMenus);
            mapaMenus.clear();
        } catch (Exception e) {
            fail("Error al limpiar los menús mediante reflexión: " + e.getMessage());
        }

        assertDoesNotThrow(() -> gestorSinMenus.mostrarTodosLosMenus());
    }}
