package org.Gestion;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductoTest {
    Producto p =new Producto(1,"Bandeja Paisa", "Plato típico paisa", 30000, "Colombiana", 30);

    @Test
    void getIdProducto() {
        assertEquals(1,p.getIdProducto());
    }

    @Test
    void getNombre() {
        assertEquals("Bandeja Paisa",p.getNombre());
    }

    @Test
    void getDescripcion() {
        assertEquals("Plato típico paisa",p.getDescripcion());

    }

    @Test
    void getPrecio() {
        assertEquals(30000,p.getPrecio());
    }

    @Test
    void isDisponible() {
        assertEquals(true,p.isDisponible());

    }

    @Test
    void getCategoria() {
        assertEquals("Colombiana",p.getCategoria());
    }

    @Test
    void getTiempoPreparacion() {
        assertEquals(30,p.getTiempoPreparacion());
    }

    @Test
    void setDisponible() {
        p.setDisponible(false);
        assertFalse(p.isDisponible());
    }

    @Test
    void setPrecio() {
        p.setPrecio(50000);
        assertEquals(50000,p.getPrecio());
    }

    @Test
    void setNombre() {
        p.setNombre("Arroz con camaron");
        assertEquals("Arroz con camaron",p.getNombre());
    }

    @Test
    void setDescripcion() {
        String desc ="Arroz con camaron acompañado de aguacates, curtido de cebolla con tomate, y salsa de aji. También se puede servir acompañado de platanos maduros fritos o de patacones.";
        p.setDescripcion("Arroz con camaron acompañado de aguacates, curtido de cebolla con tomate, y salsa de aji. También se puede servir acompañado de platanos maduros fritos o de patacones.");
        assertEquals(desc, p.getDescripcion());

    }

    @Test
    void testToString() {
        String texto =p.toString();
        assertTrue(texto.contains("Bandeja Paisa"));
        assertTrue(texto.contains("Precio"));
        assertTrue(texto.contains("Disponible"));

        p.setDisponible(false);
        String texto2 =p.toString();
        assertTrue(texto2.contains("AGOTADO"));
    }

}