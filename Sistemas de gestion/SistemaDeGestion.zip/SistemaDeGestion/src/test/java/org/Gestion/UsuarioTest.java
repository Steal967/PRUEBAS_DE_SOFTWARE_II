package org.Gestion;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {
    private Usuario usuario;
    @BeforeEach
    public void setUp() {
        usuario = new Usuario(1, "Admin", "admin", "1234");
    }

    @Test
    public void testCreacionUsuario() {
        assertNotNull(usuario);
        assertEquals(1, usuario.getIdUsuario());
        assertEquals("Admin", usuario.getNombre());
        assertEquals("admin", usuario.getRol());
    }

    @Test
    public void testValidarContrasenaCorrecta() {
        assertTrue(usuario.validarContrasena("1234"));
    }

    @Test
    public void testValidarContrasenaIncorrecta() {
        assertFalse(usuario.validarContrasena("incorrecta"));
    }

    @Test
    public void testValidarContrasenaCaseSensitive() {
        assertFalse(usuario.validarContrasena("1234 "));
        assertFalse(usuario.validarContrasena(" 1234"));
    }

    @Test
    public void testValidarContrasenaVacia() {
        Usuario usuarioSinPass = new Usuario(2, "Test", "test", "");
        assertTrue(usuarioSinPass.validarContrasena(""));
    }

    @Test
    public void testGetIdUsuario() {
        assertEquals(1, usuario.getIdUsuario());
    }

    @Test
    public void testGetNombre() {
        assertEquals("Admin", usuario.getNombre());
    }

    @Test
    public void testGetRol() {
        assertEquals("admin", usuario.getRol());
    }
}

