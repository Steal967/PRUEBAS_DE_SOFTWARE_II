package org.Gestion;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClienteTest {


            @Test
            void testCrearCliente() {
                Cliente cliente = new Cliente(1, "Juan", "3001234567");
                assertNotNull(cliente);
                assertEquals("Juan", cliente.getNombre());
                assertEquals("3001234567", cliente.getContacto());
            }


@Test
void testAsignarDireccion() {
    Cliente cliente = new Cliente(2, "Ana", "3010000000");
    cliente.setDireccion("Calle 10 #5-30");
    assertEquals("Calle 10 #5-30", cliente.getDireccion());
}

@Test
void testAsignarMesa() {
    Cliente cliente = new Cliente(3, "Carlos", "3021111111");
    cliente.setMesa(8);
    assertEquals(8, cliente.getMesa());
}

@Test
void testValoresInicialesNulos() {
    Cliente cliente = new Cliente(4, "Laura", "3032222222");
    assertNull(cliente.getDireccion());
    assertNull(cliente.getMesa());
}
}

