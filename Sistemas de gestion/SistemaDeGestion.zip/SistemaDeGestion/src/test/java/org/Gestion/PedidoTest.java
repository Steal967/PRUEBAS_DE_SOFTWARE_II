package org.Gestion;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PedidoTest {
    @Test
    void agregarDetalle() {
        Cliente cliente = new Cliente(1,"Sanriago","123456789");
        Pedido pedido = new Pedido(cliente);
        Producto producto = new Producto(1,"Hamburguesa","especial",15000,"comida rapida",15);
        DetallePedido detalle = new DetallePedido(producto,2);

        pedido.agregarDetalle(detalle);

        assertEquals(30000,pedido.getTotal());
        assertEquals(1,pedido.getDetalles().size());
    }

    @Test
    void aplicarDescuento() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        Producto producto = new Producto(1,"Hamburguesa","especial",15000,"comida rapida",15);
        pedido.agregarDetalle(new DetallePedido(producto,1));

        pedido.aplicarDescuento(15);
        assertEquals(12750,pedido.getTotal());
        assertEquals(1,pedido.getDetalles().size());
    }

    @Test
    void getTiempoEstimado() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        Producto p1 = new Producto(1,"Hamburguesa","especial",15000,"comida rapida",15);
        Producto p2 = new Producto(2,"Lasgna","Mixta",20000,"comida rapida",25);

        pedido.agregarDetalle(new DetallePedido(p2,1));
        pedido.agregarDetalle(new DetallePedido(p1,1));


        assertEquals(25,pedido.getTiempoEstimado());
    }

    @Test
    void cambiarEstado() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        pedido.cambiarEstado("Entregado");
        assertEquals("Entregado",pedido.getEstado());
    }

    @Test
    void setMetodoPago() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        pedido.setMetodoPago("Tarjeta Debito");
        assertEquals("Tarjeta Debito",pedido.getMetodoPago());
    }

    @Test
    void getIdPedido() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        assertTrue(pedido.getIdPedido() > 0);
    }

    @Test
    void getCliente() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        assertEquals(cliente,pedido.getCliente());
    }

    @Test
    void getEstado() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        assertEquals("Pendiente",pedido.getEstado());

    }

    @Test
    void getTotal() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        Producto producto = new Producto(1,"Hamburguesa","especial",15000,"comida rapida",15);
        pedido.agregarDetalle(new DetallePedido(producto,2));
        assertEquals(30000,pedido.getTotal());
    }

    @Test
    void getDetalles() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        Producto producto = new Producto(1,"Hamburguesa","especial",15000,"comida rapida",15);
        pedido.agregarDetalle(new DetallePedido(producto,1));
        assertFalse(pedido.getDetalles().isEmpty());
    }

    @Test
    void getMetodoPago() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        pedido.setMetodoPago("Efectivo");
        assertEquals("Efectivo",pedido.getMetodoPago());
    }

    @Test
    void getFechaHora() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        assertNotNull(pedido.getFechaHora());
    }

    @Test
    void getDescuento() {
        Cliente cliente = new Cliente(1,"Santiago","123456789");
        Pedido pedido = new Pedido(cliente);
        pedido.aplicarDescuento(20);
        assertEquals(20,pedido.getDescuento());
    }

    @Test
    void getResumen() {
        Cliente cliente = new Cliente(1, "Santiago", "123456789");
        Pedido pedido = new Pedido(cliente);
        Producto producto = new Producto(1, "Hamburguesa", "especial", 15000, "comida rapida", 15);
        pedido.agregarDetalle(new DetallePedido(producto, 2));
        pedido.aplicarDescuento(10);

        String resumen = pedido.getResumen();

        assertTrue(resumen.contains("Hamburguesa"));
        assertTrue(resumen.contains("Santiago"));
        assertTrue(resumen.contains("Descuento: 10%"));
        assertTrue(resumen.contains("TOTAL"));
        assertTrue(resumen.contains("Tiempo estimado"));

    }

}