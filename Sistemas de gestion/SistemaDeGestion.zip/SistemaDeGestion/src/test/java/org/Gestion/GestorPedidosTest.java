package org.Gestion;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

public class GestorPedidosTest {

    private GestorPedidos gestor;
    private Cliente cliente;
    private Producto producto1;
    private Producto producto2;
    private Producto producto3;

    @BeforeEach
    void setUp() {
        gestor = new GestorPedidos();
        cliente = new Cliente(1, "Steven", "3001234567");
        producto1 = new Producto(1, "Hamburguesa", "Carne y queso", 15000, "Comida", 10);
        producto2 = new Producto(2, "Gaseosa", "Bebida fría", 5000, "Bebida", 2);
        producto3 = new Producto(3, "Postre", "Chocolate", 7000, "Postre", 5);
    }

    @Test
    void testCrearPedido() {
        Pedido pedido = gestor.crearPedido(cliente);
        assertNotNull(pedido);
        assertEquals(cliente, pedido.getCliente());
        assertEquals("Pendiente", pedido.getEstado());
        assertTrue(gestor.obtenerPedido(pedido.getIdPedido()) != null);
    }

    @Test
    void testObtenerPedidoExistente() {
        Pedido pedido = gestor.crearPedido(cliente);
        Pedido resultadoActual = gestor.obtenerPedido(pedido.getIdPedido());
        assertEquals(pedido, resultadoActual);
    }

    @Test
    void testObtenerPedidoInexistente() {
        Pedido resultadoActual = gestor.obtenerPedido(999);
        assertNull(resultadoActual);
    }

    @Test
    void testListarPedidosPendientes() {
        Pedido pedido1 = gestor.crearPedido(cliente);
        Pedido pedido2 = gestor.crearPedido(cliente);
        pedido2.cambiarEstado("Servido");
        List<Pedido> resultadoActual = gestor.listarPedidosPendientes();
        assertEquals(1, resultadoActual.size());
        assertEquals("Pendiente", resultadoActual.get(0).getEstado());
    }

    @Test
    void testListarPorEstado() {
        Pedido pedido1 = gestor.crearPedido(cliente);
        Pedido pedido2 = gestor.crearPedido(cliente);
        pedido1.cambiarEstado("Servido");
        List<Pedido> resultadoActual = gestor.listarPorEstado("Servido");
        assertEquals(1, resultadoActual.size());
        assertEquals("Servido", resultadoActual.get(0).getEstado());
    }

    @Test
    void testListarPorEstadoVacio() {
        List<Pedido> resultadoActual = gestor.listarPorEstado("Cancelado");
        assertTrue(resultadoActual.isEmpty());
    }

    @Test
    void testFinalizarPedido() {
        Pedido pedido = gestor.crearPedido(cliente);
        pedido.agregarDetalle(new DetallePedido(producto1, 2));
        gestor.finalizarPedido(pedido.getIdPedido());
        assertNull(gestor.obtenerPedido(pedido.getIdPedido()));
        assertEquals(1, gestor.getHistorial().size());
    }

    @Test
    void testFinalizarPedidoInexistente() {
        gestor.finalizarPedido(999);
        assertTrue(gestor.getHistorial().isEmpty());
    }

    @Test
    void testGetHistorial() {
        Pedido pedido = gestor.crearPedido(cliente);
        pedido.agregarDetalle(new DetallePedido(producto2, 3));
        gestor.finalizarPedido(pedido.getIdPedido());
        List<Pedido> resultadoActual = gestor.getHistorial();
        assertEquals(1, resultadoActual.size());
        assertEquals(pedido, resultadoActual.get(0));
    }

    @Test
    void testGetTotalVentas() {
        Pedido pedido1 = gestor.crearPedido(cliente);
        pedido1.agregarDetalle(new DetallePedido(producto1, 2));
        gestor.finalizarPedido(pedido1.getIdPedido());

        Pedido pedido2 = gestor.crearPedido(cliente);
        pedido2.agregarDetalle(new DetallePedido(producto2, 4));
        gestor.finalizarPedido(pedido2.getIdPedido());

        double resultadoEsperado = (15000 * 2) + (5000 * 4);
        double resultadoActual = gestor.getTotalVentas();
        assertEquals(resultadoEsperado, resultadoActual);
    }

    @Test
    void testGetProductosMasVendidos() {
        Pedido pedido1 = gestor.crearPedido(cliente);
        pedido1.agregarDetalle(new DetallePedido(producto1, 2));
        pedido1.agregarDetalle(new DetallePedido(producto2, 1));
        gestor.finalizarPedido(pedido1.getIdPedido());

        Pedido pedido2 = gestor.crearPedido(cliente);
        pedido2.agregarDetalle(new DetallePedido(producto1, 3));
        gestor.finalizarPedido(pedido2.getIdPedido());

        Map<String, Integer> resultadoActual = gestor.getProductosMasVendidos();
        assertEquals(2, resultadoActual.size());
        assertEquals(5, resultadoActual.get("Hamburguesa"));
        assertEquals(1, resultadoActual.get("Gaseosa"));
    }

    @Test
    void testGetProductosMasVendidosVacio() {
        Map<String, Integer> resultadoActual = gestor.getProductosMasVendidos();
        assertTrue(resultadoActual.isEmpty());
    }

    @Test
    void testGetVentasPorCategoria() {
        Pedido pedido1 = gestor.crearPedido(cliente);
        pedido1.agregarDetalle(new DetallePedido(producto1, 2));
        pedido1.agregarDetalle(new DetallePedido(producto2, 1));
        gestor.finalizarPedido(pedido1.getIdPedido());

        Pedido pedido2 = gestor.crearPedido(cliente);
        pedido2.agregarDetalle(new DetallePedido(producto3, 3));
        gestor.finalizarPedido(pedido2.getIdPedido());

        Map<String, Double> resultadoActual = gestor.getVentasPorCategoria();
        double resultadoEsperadoComida = 15000 * 2;
        double resultadoEsperadoBebida = 5000 * 1;
        double resultadoEsperadoPostre = 7000 * 3;

        assertEquals(3, resultadoActual.size());
        assertEquals(resultadoEsperadoComida, resultadoActual.get("Comida"));
        assertEquals(resultadoEsperadoBebida, resultadoActual.get("Bebida"));
        assertEquals(resultadoEsperadoPostre, resultadoActual.get("Postre"));
    }

    @Test
    void testGetVentasPorCategoriaVacio() {
        Map<String, Double> resultadoActual = gestor.getVentasPorCategoria();
        assertTrue(resultadoActual.isEmpty());
    }
}
