package org.Gestion;

import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;

class SistemaRestauranteTest {
    SistemaRestaurante sistema = new SistemaRestaurante();

    @Test
    void testInicializacionSistema() {
        assertNotNull(sistema);
    }

    @Test
    public void testRealizarPedidoSimulado() {
        String inputSimulado = String.join("\n", "Juan","123456789","3","0","0");
        ByteArrayInputStream entrada = new ByteArrayInputStream(inputSimulado.getBytes());
        System.setIn(entrada);
        SistemaRestaurante sistema = new SistemaRestaurante();
        sistema.iniciar();
    }

    @Test
    public void testMenuCocineroOpcionInvalidaYSalir() {
        String inputSimulado = "9\n0\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.menuCocinero());
    }

    @Test
    public void testRealizarPedidoMetodoPagoTarjeta() {
        String input = "1\n1\n0\nn\n2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        Cliente cliente = new Cliente(7,"Carlos", "654");
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testRealizarPedidoDescuentoInvalido() {
        String input = "1\n1\n0\ns\nabc\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        Cliente cliente = new Cliente(6,"Sofía", "3213248923");
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testRealizarPedidoProductoNoExiste() {
        String input = "999\n0\nn\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        Cliente cliente = new Cliente(3,"Ana", "456");
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testMenuCocineroVerPedidosPendientes() {
        String inputSimulado = "1\n0\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.menuCocinero());
    }

    @Test
    public void testMenuCocineroCambiarEstadoPedidoInexistente() {
        String inputSimulado = "3\n999\n0\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.menuCocinero());
    }

    @Test
    public void testMenuCocineroVerPedidosEnPreparacion() {
        String inputSimulado = "2\n0\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.menuCocinero());
    }

    @Test
    public void testRealizarPedidoCantidadInvalida() {
        String input = "1\n0\n0\nn\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        Cliente cliente = new Cliente(6,"Luis", "382929789");
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testEditarProductoSinCambios() {
        String inputSimulado = "1\n\n\n\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.editarProducto());
    }

    @Test
    public void testClientePuedePedir() {
        Cliente cliente = new Cliente(3,"Pedro", "222");
        assertTrue(cliente != null && cliente.getNombre().length() > 0);
    }

    @Test
    public void testEliminarProductoInexistente() {
        String inputSimulado = "99\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.eliminarProducto());
    }

    @Test
    public void testCambiarDisponibilidadProductoInexistente() {
        String inputSimulado = "99\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.cambiarDisponibilidad());
    }

    @Test
    public void testModificarPrecioInvalido() {
        String inputSimulado = "1\nabc\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.modificarPrecio());
    }

    @Test
    public void testClienteValido() {
        Cliente cliente = new Cliente(5,"Pedro", "222");
        assertTrue(cliente.getNombre().length() > 0);
    }

    @Test
    public void testLeerIdPedidoCorrecto() {
        String input = "5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        int id = sistema.leerOpcion();
        assertEquals(5, id);
    }

    @Test
    public void testClienteValidoParaPedido() {
        Cliente cliente = new Cliente(7,"Natalia", "321828277");
        assertTrue(cliente.getNombre().length() > 0);
    }

    @Test
    public void testNombreClienteDistinto() {
        Cliente cliente = new Cliente(9,"Natalia", "777");
        assertNotEquals("Pedro", cliente.getNombre());
    }

    @Test
    public void testMetodoPagoNoSeaTarjeta() {
        Pedido pedido = new Pedido(new Cliente(5, "Maria","3113456722"));
        pedido.setMetodoPago("Efectivo");
        assertNotEquals("Tarjeta", pedido.getMetodoPago());
    }

    @Test
    public void testConsultarEstadoPedidoInexistente() {
        String input = "999\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.consultarEstadoPedido());
    }

    @Test
    public void testAplicarPromocionConDescuentoInvalido() {
        String inputSimulado = "Taco\nabc\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.aplicarPromocion());
    }

    @Test
    public void testConsultarEstadoPedidoValido() {
        String input = "1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.consultarEstadoPedido());
    }

    @Test
    public void testLeerOpcionSimulada() {
        String input = "2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        int opcion = sistema.leerOpcion();
        assertEquals(2, opcion);
    }

    @Test
    public void testLeerOpcionValida() {
        String inputSimulado = "3\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        int opcion = sistema.leerOpcion();
        assertEquals(3, opcion);
    }

    @Test
    public void testClienteValidoParaConsulta() {
        Cliente cliente = new Cliente(5,"Natalia", "3123444577");
        assertTrue(cliente.getNombre().length() > 0);
    }

    @Test
    public void testReporteVentasSinHistorial() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.reporteVentas());
    }

    @Test
    public void testProductosMasVendidosSinDatos() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.productosMasVendidos());
    }

    @Test
    public void testLeerOpcionCorrecta() {
        String input = "2\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        int opcion = sistema.leerOpcion();
        assertEquals(2, opcion);
    }

    @Test
    public void testRealizarPedidoSinProductos() {
        String inputSimulado = "0\nn\n1\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        Cliente cliente = new Cliente(2, "Juan","3237381002");
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testMenuClienteSalir() {
        String inputSimulado = "Juan\n123456789\n0\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.menuCliente());
    }

    @Test
    public void testAgregarProductoConDatosInvalidos() {
        String inputSimulado = "1\nPizza\nDeliciosa\nabc\nItaliana\n15\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.agregarProducto());
    }

    @Test
    public void testProductoNoDisponible() {
        Producto producto = new Producto(2, "Empanada", "Carne", 3.0, "Colombiana", 8);
        producto.setDisponible(false);
        assertFalse(producto.isDisponible());
    }

    @Test
    public void testCambiarEstadoPedidoInexistente() {
        String inputSimulado = "999\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.cambiarEstadoPedido());
    }

    @Test
    public void testMostrarMenuPorCategoriaItaliana() {
        String inputSimulado = "2\n";
        System.setIn(new ByteArrayInputStream(inputSimulado.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.mostrarMenuPorCategoria());
    }

    @Test
    public void testVentasPorCategoriaSinDatos() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.ventasPorCategoria());
    }

    @Test
    public void testProductoInexistente() {
        GestorProductos gestor = new GestorProductos();
        Producto producto = gestor.obtenerProducto(999);
        assertNull(producto);
    }

    @Test
    public void testPedidoConProductoYCantidadValida() {
        String input = "1\n2\n0\nn\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        Cliente cliente = new Cliente(8,"Laura", "3288555111");
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testPedidoSinProductos() {
        String input = "0\nn\n1\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        Cliente cliente = new Cliente(1,"Juan", "3143423323");
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.realizarPedido(cliente));
    }

    @Test
    public void testGestionarProductosSalir() {
        String input = "0\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.gestionarProductos());
    }

    @Test
    public void testProductosMasVendidos() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.productosMasVendidos());
    }

    @Test
    public void testVentasPorCategoria() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.ventasPorCategoria());
    }

    @Test
    public void testAgregarProductoValido() {
        String input = "10\nPizza\nDeliciosa\n25.5\nItaliana\n15\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.agregarProducto());
    }

    @Test
    public void testAgregarProductoPrecioInvalido() {
        String input = "11\nTaco\nPicante\nabc\nMexicana\n10\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.agregarProducto());
    }

    @Test
    public void testAgregarProductoSinAccederAGestor() {
        String input = "40\nPan\nIntegral\n3.5\nColombiana\n5\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.agregarProducto());
    }

    @Test
    public void testAgregarProductoCategoriaNoEsperada() {
        String input = "43\nTé\nVerde\n3.0\nJaponesa\n4\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.agregarProducto());
    }

    @Test
    public void testAgregarProductoPrecioDecimalLargo() {
        String input = "45\nBrownie\nChocolate\n3.14159\nColombiana\n7\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.agregarProducto());
    }

    @Test
    public void testListarPedidosActivosSinPedidos() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.listarPedidosActivos());
    }

    @Test
    public void testEntradaSimuladaComoArray() {
        String[] esperado = {"1", "3"};
        String input = String.join("\n", esperado) + "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        String[] recibido = new String[2];
        Scanner scanner = new Scanner(System.in);
        recibido[0] = scanner.nextLine();
        recibido[1] = scanner.nextLine();
        assertArrayEquals(esperado, recibido);
    }

    @Test
    public void testCambiarEstadoPedidoEntradaConEspacios() {
        String input = "   \n   \n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.cambiarEstadoPedido());
    }

    @Test
    public void testEntradaSimuladaCambioEstado() {
        String[] esperado = {"1", "4"};
        String input = String.join("\n", esperado) + "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        String[] recibido = new String[2];
        Scanner scanner = new Scanner(System.in);
        recibido[0] = scanner.nextLine();
        recibido[1] = scanner.nextLine();
        assertArrayEquals(esperado, recibido);
    }

    @Test
    public void testEntradaSimuladaGestionProductos() {
        String[] esperado = {"1", "10", "Pan", "Integral", "3.0", "Colombiana", "5"};
        String input = String.join("\n", esperado) + "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        String[] recibido = new String[7];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 7; i++) {
            recibido[i] = scanner.nextLine();
        }
        assertArrayEquals(esperado, recibido);
    }

    @Test
    public void testMenuAdministradorOpcionInvalidaYSalir() {
        String input = "9\n0\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.menuAdministrador());
    }

    @Test
    public void testCambiarDisponibilidadProductoExistente() {
        String input = "1\ns\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.cambiarDisponibilidad());
    }

    @Test
    public void testListarPedidosPorEstadoEntregado() {
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.listarPedidosPorEstado("Entregado"));
    }

    @Test
    public void testModificarPrecioValido() {
        String input = "1\n25000\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        SistemaRestaurante sistema = new SistemaRestaurante();
        assertDoesNotThrow(() -> sistema.modificarPrecio());
    }








}