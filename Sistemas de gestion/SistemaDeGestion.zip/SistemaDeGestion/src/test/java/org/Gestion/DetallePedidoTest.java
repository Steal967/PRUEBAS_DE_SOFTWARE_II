package org.Gestion;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DetallePedidoTest {
    @Test

    void testcrearProducto() {
        Producto producto = new Producto(10, "Salchipapa", "Salchipapa con papas y salsa", 12000.0, "Comida rápida", 8);

        DetallePedido detalle = new DetallePedido(producto, 3);


        assertEquals(producto, detalle.getProducto(), "El producto del detalle no coincide");
        assertEquals(3, detalle.getCantidad(), "La cantidad no coincide");
        assertEquals(36000.0, detalle.getSubtotal(), "El subtotal debería ser 36000");
        assertTrue(detalle.getIdDetalle() > 0, "El ID del detalle debe ser mayor que 0");
        assertEquals(24, detalle.getTiempoPreparacion(), "El tiempo total de preparación debería ser 24");
    }
}