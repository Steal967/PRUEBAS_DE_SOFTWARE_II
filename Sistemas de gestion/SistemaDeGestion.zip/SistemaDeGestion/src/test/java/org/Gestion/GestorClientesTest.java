package org.Gestion;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GestorClientesTest {
    GestorClientes gestor = new GestorClientes();
    @Test
    void testRegistrarCliente() {
        Cliente cliente = gestor.registrarCliente("Juan", "3001234567");

        assertNotNull(cliente);
        assertEquals(1, cliente.getIdUsuario());
        assertEquals("Juan", cliente.getNombre());
        assertEquals("3001234567", cliente.getContacto());
        assertEquals(cliente, gestor.obtenerCliente(1));
    }
    @Test
    void testRegistrarVariosClientes() {
        Cliente c1 = gestor.registrarCliente("Ana", "3011478511");
        Cliente c2 = gestor.registrarCliente("Pedro", "3158555482");

        assertEquals(1, c1.getIdUsuario());
        assertEquals(2, c2.getIdUsuario());
        assertEquals(2, gestor.getClientes().size());
    }
    @Test
    void testClientesInexistentes() {
        Cliente cliente = gestor.obtenerCliente(1029);
        assertNull(cliente);
    }}