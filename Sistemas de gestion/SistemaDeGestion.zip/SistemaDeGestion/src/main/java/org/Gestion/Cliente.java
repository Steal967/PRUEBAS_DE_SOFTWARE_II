package org.Gestion;

public class Cliente extends Usuario {
    private String contacto;
    private String direccion;
    private Integer mesa;

    public Cliente(int id, String nombre, String contacto) {
        super(id, nombre, "cliente", "");
        this.contacto = contacto;
    }

    public void setMesa(Integer mesa) {
        this.mesa = mesa;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Integer getMesa() {
        return mesa;
    }

    public String getContacto() {
        return contacto;
    }

    public String getDireccion() {
        return direccion;
    }
}

