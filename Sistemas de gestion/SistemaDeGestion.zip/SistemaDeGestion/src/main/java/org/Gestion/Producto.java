package org.Gestion;

public class Producto {
    private int idProducto;
    private String nombre;
    private String descripcion;
    private double precio;
    private boolean disponible;
    private String categoria;
    private int tiempoPreparacion;

    public Producto(int id, String nombre, String descripcion, double precio, String categoria, int tiempo) {
        this.idProducto = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.categoria = categoria;
        this.tiempoPreparacion = tiempo;
        this.disponible = true;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getTiempoPreparacion() {
        return tiempoPreparacion;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return String.format("[%d] %s - %s\n    Precio: $%.2f | Tiempo: %d min | %s",
                idProducto, nombre, descripcion, precio, tiempoPreparacion,
                disponible ? "Disponible" : "AGOTADO");
    }
}