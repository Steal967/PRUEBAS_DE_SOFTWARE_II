package org.Gestion;

public class DetallePedido {
    private static int contadorId = 1;
    private int idDetalle;
    private Producto producto;
    private int cantidad;
    private double subtotal;

    public DetallePedido(Producto producto, int cantidad) {
        this.idDetalle = contadorId++;
        this.producto = producto;
        this.cantidad = cantidad;
        this.subtotal = producto.getPrecio() * cantidad;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public int getTiempoPreparacion() {
        return producto.getTiempoPreparacion() * cantidad;
    }
}