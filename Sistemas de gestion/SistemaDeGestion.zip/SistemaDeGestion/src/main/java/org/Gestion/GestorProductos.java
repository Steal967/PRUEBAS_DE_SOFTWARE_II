package org.Gestion;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class GestorProductos {
    private Map<Integer, Producto> productos;
    private Map<String, Double> promociones;
    private Map<Integer, Menu> menus;
    private int contadorMenus;

    public GestorProductos() {
        productos = new HashMap<>();
        promociones = new HashMap<>();
        menus = new HashMap<>();
        contadorMenus = 1;
        cargarProductosIniciales();
        crearMenusIniciales();
    }

    private void cargarProductosIniciales() {
        // Gastronomía Mexicana
        agregarProducto(new Producto(1, "Tacos al Pastor", "3 tacos con piña y cilantro", 15000, "Mexicana", 15));
        agregarProducto(new Producto(2, "Quesadillas", "Con queso y proteína a elección", 12000, "Mexicana", 10));
        agregarProducto(new Producto(3, "Guacamole", "Con totopos", 8000, "Mexicana", 5));

        // Gastronomía Italiana
        agregarProducto(new Producto(4, "Pizza Margherita", "Tomate, mozzarella y albahaca", 25000, "Italiana", 20));
        agregarProducto(new Producto(5, "Pasta Carbonara", "Con tocino y crema", 22000, "Italiana", 18));
        agregarProducto(new Producto(6, "Lasagna", "Carne, pasta y queso", 28000, "Italiana", 25));

        // Gastronomía Colombiana
        agregarProducto(new Producto(7, "Bandeja Paisa", "Plato típico completo", 30000, "Colombiana", 30));
        agregarProducto(new Producto(8, "Ajiaco", "Sopa con pollo y papa", 18000, "Colombiana", 20));
        agregarProducto(new Producto(9, "Arepa con Queso", "Arepa tradicional", 8000, "Colombiana", 8));
    }

    private void crearMenusIniciales() {
        // Crear menú para cada tipo de gastronomía
        Menu menuMexicano = new Menu(1, "Menú Mexicano");
        Menu menuItaliano = new Menu(2, "Menú Italiano");
        Menu menuColombiano = new Menu(3, "Menú Colombiano");

        // Agregar productos a cada menú
        for (Producto p : productos.values()) {
            if (p.getCategoria().equals("Mexicana")) {
                menuMexicano.agregarProducto(p);
            } else if (p.getCategoria().equals("Italiana")) {
                menuItaliano.agregarProducto(p);
            } else if (p.getCategoria().equals("Colombiana")) {
                menuColombiano.agregarProducto(p);
            }
        }

        menus.put(1, menuMexicano);
        menus.put(2, menuItaliano);
        menus.put(3, menuColombiano);
        contadorMenus = 4;
    }

    public void agregarProducto(Producto producto) {
        productos.put(producto.getIdProducto(), producto);
    }

    public boolean eliminarProducto(int id) {
        Producto productoEliminado = productos.remove(id);
        if (productoEliminado != null) {
            // Eliminar también de todos los menús
            for (Menu menu : menus.values()) {
                menu.eliminarProducto(productoEliminado);
            }
            return true;
        }
        return false;
    }

    public Producto obtenerProducto(int id) {
        return productos.get(id);
    }

    public List<Producto> listarTodos() {
        return new ArrayList<>(productos.values());
    }

    public List<Producto> listarPorCategoria(String categoria) {
        List<Producto> productosFiltrados = new ArrayList<>();
        for (Producto p : productos.values()) {
            if (p.getCategoria().equals(categoria)) {
                productosFiltrados.add(p);
            }
        }
        return productosFiltrados;
    }

    public void aplicarPromocion(String nombreProducto, double descuento) {
        promociones.put(nombreProducto, descuento);
    }

    public boolean hayProductos() {
        return !productos.isEmpty();
    }

    public Map<String, Double> getPromociones() {
        return promociones;
    }

    // ========== MÉTODOS PARA GESTIONAR MENÚS ==========

    public Menu crearMenu(String nombre) {
        Menu nuevoMenu = new Menu(contadorMenus++, nombre);
        menus.put(nuevoMenu.getIdMenu(), nuevoMenu);
        return nuevoMenu;
    }

    public Menu obtenerMenu(int idMenu) {
        return menus.get(idMenu);
    }

    public List<Menu> listarMenus() {
        return new ArrayList<>(menus.values());
    }

    public void agregarProductoAMenu(int idMenu, int idProducto) {
        Menu menu = menus.get(idMenu);
        Producto producto = productos.get(idProducto);

        if (menu != null && producto != null) {
            menu.agregarProducto(producto);
        }
    }

    public void eliminarProductoDeMenu(int idMenu, int idProducto) {
        Menu menu = menus.get(idMenu);
        Producto producto = productos.get(idProducto);

        if (menu != null && producto != null) {
            menu.eliminarProducto(producto);
        }
    }

    public void mostrarMenu(int idMenu) {
        Menu menu = menus.get(idMenu);
        if (menu != null) {
            menu.mostrarMenu();
        } else {
            System.out.println("⚠️  Menú no encontrado");
        }
    }

    public void mostrarTodosLosMenus() {
        if (menus.isEmpty()) {
            System.out.println("\n⚠️  No hay menús disponibles");
            return;
        }

        System.out.println("\n╔════════════════════════════════════════════════════════════╗");
        System.out.println("  ║                    MENÚS DISPONIBLES                       ║");
        System.out.println("  ╚════════════════════════════════════════════════════════════╝\n");

        for (Menu menu : menus.values()) {
            System.out.println(menu);
        }
    }
}