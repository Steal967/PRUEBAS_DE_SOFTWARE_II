package org.Gestion;

import java.util.HashMap;
import java.util.Map;

public class GestorClientes {
    private Map<Integer, Cliente> clientes;
    private int contadorId;

    public GestorClientes() {
        clientes = new HashMap<>();
        contadorId = 1;
    }

    public Cliente registrarCliente(String nombre, String contacto) {
        Cliente cliente = new Cliente(contadorId++, nombre, contacto);
        clientes.put(cliente.getIdUsuario(), cliente);
        return cliente;
    }

    public Cliente obtenerCliente(int id) {
        return clientes.get(id);
    }

    public Map<Integer, Cliente> getClientes() {
        return clientes;
    }
}