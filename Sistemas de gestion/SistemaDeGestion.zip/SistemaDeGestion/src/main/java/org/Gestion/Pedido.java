package org.Gestion;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private static int contadorId = 1;
    private int idPedido;
    private Cliente cliente;
    private LocalDateTime fechaHora;
    private String estado;
    private List<DetallePedido> detalles;
    private double total;
    private double descuento;
    private String metodoPago;

    public Pedido(Cliente cliente) {
        this.idPedido = contadorId++;
        this.cliente = cliente;
        this.fechaHora = LocalDateTime.now();
        this.estado = "Pendiente";
        this.detalles = new ArrayList<>();
        this.descuento = 0;
    }

    public void agregarDetalle(DetallePedido detalle) {
        detalles.add(detalle);
        calcularTotal();
    }

    public void aplicarDescuento(double porcentaje) {
        this.descuento = porcentaje;
        calcularTotal();
    }

    private void calcularTotal() {
        total = 0;
        for (DetallePedido detalle : detalles) {
            total += detalle.getSubtotal();
        }
        total = total * (1 - descuento / 100);
    }

    public int getTiempoEstimado() {
        int tiempoMaximo = 0;
        for (DetallePedido detalle : detalles) {
            int tiempo = detalle.getTiempoPreparacion();
            if (tiempo > tiempoMaximo) {
                tiempoMaximo = tiempo;
            }
        }
        return tiempoMaximo;
    }

    public void cambiarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
    }

    public void setMetodoPago(String metodo) {
        this.metodoPago = metodo;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public String getEstado() {
        return estado;
    }

    public double getTotal() {
        return total;
    }

    public List<DetallePedido> getDetalles() {
        return detalles;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public double getDescuento() {
        return descuento;
    }

    public String getResumen() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════╗\n");
        sb.append(String.format("  PEDIDO #%d\n", idPedido));
        sb.append("  ╠══════════════════════════════════════════════╣\n");
        sb.append(String.format("  Cliente: %s\n", cliente.getNombre()));
        sb.append(String.format("  Fecha: %s\n", fechaHora.format(formatter)));
        sb.append(String.format("  Estado: %s\n", estado));
        sb.append("  ╠══════════════════════════════════════════════╣\n");
        for (DetallePedido d : detalles) {
            sb.append(String.format("  %dx %s - $%.2f\n",
                    d.getCantidad(), d.getProducto().getNombre(), d.getSubtotal()));
        }
        sb.append("  ╠══════════════════════════════════════════════╣\n");
        if (descuento > 0) {
            sb.append(String.format("  Descuento: %.0f%%\n", descuento));
        }
        sb.append(String.format("  TOTAL: $%.2f\n", total));
        sb.append(String.format("  Tiempo estimado: %d min\n", getTiempoEstimado()));
        sb.append("  ╚══════════════════════════════════════════════╝\n");
        return sb.toString();
    }
}