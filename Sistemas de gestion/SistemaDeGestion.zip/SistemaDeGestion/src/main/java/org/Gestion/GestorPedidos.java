package org.Gestion;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class GestorPedidos {
    private Map<Integer, Pedido> pedidos;
    private List<Pedido> historial;

    public GestorPedidos() {
        pedidos = new HashMap<>();
        historial = new ArrayList<>();
    }

    public Pedido crearPedido(Cliente cliente) {
        Pedido pedido = new Pedido(cliente);
        pedidos.put(pedido.getIdPedido(), pedido);
        return pedido;
    }

    public Pedido obtenerPedido(int id) {
        return pedidos.get(id);
    }

    public List<Pedido> listarPedidosPendientes() {
        List<Pedido> pendientes = new ArrayList<>();
        for (Pedido p : pedidos.values()) {
            if (!p.getEstado().equals("Servido")) {
                pendientes.add(p);
            }
        }
        return pendientes;
    }

    public List<Pedido> listarPorEstado(String estado) {
        List<Pedido> filtrados = new ArrayList<>();
        for (Pedido p : pedidos.values()) {
            if (p.getEstado().equals(estado)) {
                filtrados.add(p);
            }
        }
        return filtrados;
    }

    public void finalizarPedido(int idPedido) {
        Pedido pedido = pedidos.remove(idPedido);
        if (pedido != null) {
            historial.add(pedido);
        }
    }

    public List<Pedido> getHistorial() {
        return new ArrayList<>(historial);
    }

    public double getTotalVentas() {
        double total = 0;
        for (Pedido p : historial) {
            total += p.getTotal();
        }
        return total;
    }

    public Map<String, Integer> getProductosMasVendidos() {
        Map<String, Integer> ventas = new HashMap<>();
        for (Pedido p : historial) {
            for (DetallePedido d : p.getDetalles()) {
                String nombre = d.getProducto().getNombre();
                ventas.put(nombre, ventas.getOrDefault(nombre, 0) + d.getCantidad());
            }
        }
        return ventas;
    }

    public Map<String, Double> getVentasPorCategoria() {
        Map<String, Double> ventasCat = new HashMap<>();
        for (Pedido p : historial) {
            for (DetallePedido d : p.getDetalles()) {
                String cat = d.getProducto().getCategoria();
                ventasCat.put(cat, ventasCat.getOrDefault(cat, 0.0) + d.getSubtotal());
            }
        }
        return ventasCat;
    }
}