package org.Gestion;

import java.util.Scanner;
import java.util.List;
import java.util.Map;

public class SistemaRestaurante {
    private GestorProductos gestorProductos;
    private GestorPedidos gestorPedidos;
    private GestorClientes gestorClientes;
    private Scanner scanner;
    private boolean cocineroActivo;

    public SistemaRestaurante() {
        gestorProductos = new GestorProductos();
        gestorPedidos = new GestorPedidos();
        gestorClientes = new GestorClientes();
        scanner = new Scanner(System.in);
        cocineroActivo = true;
    }

    public void iniciar() {
        while (true) {
            mostrarMenuPrincipal();
            int opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    menuCliente();
                    break;
                case 2:
                    menuCocinero();
                    break;
                case 3:
                    menuAdministrador();
                    break;
                case 0:
                    System.out.println("\n¡Gracias por usar el sistema!");
                    scanner.close();
                    return;
                default:
                    System.out.println("\nOpción inválida");
            }
        }
    }

    private void mostrarMenuPrincipal() {
        System.out.println("  ╔════════════════════════════════════════════╗");
        System.out.println("  ║       SISTEMA DE GESTIÓN DE PEDIDOS        ║");
        System.out.println("  ║       Restaurante Multigastronómico        ║");
        System.out.println("  ╠════════════════════════════════════════════╣");
        System.out.println("  ║  1. Módulo Cliente                         ║");
        System.out.println("  ║  2. Módulo Cocinero                        ║");
        System.out.println("  ║  3. Módulo Administrador                   ║");
        System.out.println("  ║  0. Salir                                  ║");
        System.out.println("  ╚════════════════════════════════════════════╝");
        System.out.print("Seleccione una opción: ");
    }

    int leerOpcion() {
        try {
            int opcion = Integer.parseInt(scanner.nextLine());
            return opcion;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ========== MÓDULO CLIENTE ==========
    void menuCliente() {
        System.out.println("\n=== REGISTRO RÁPIDO ===");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Contacto: ");
        String contacto = scanner.nextLine();

        Cliente cliente = gestorClientes.registrarCliente(nombre, contacto);
        System.out.println("✓ Bienvenido " + nombre + "!");

        while (true) {
            System.out.println("\n╔════════════════════════════════════════════╗");
            System.out.println("  ║                MENÚ CLIENTE                ║");
            System.out.println("  ╠════════════════════════════════════════════╣");
            System.out.println("  ║  1. Ver menú completo                      ║");
            System.out.println("  ║  2. Ver menú por gastronomía               ║");
            System.out.println("  ║  3. Hacer pedido                           ║");
            System.out.println("  ║  4. Consultar estado de pedido             ║");
            System.out.println("  ║  0. Volver                                 ║");
            System.out.println("  ╚════════════════════════════════════════════╝");
            System.out.print("Opción: ");

            int opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    mostrarMenu();
                    break;
                case 2:
                    mostrarMenuPorCategoria();
                    break;
                case 3:
                    realizarPedido(cliente);
                    break;
                case 4:
                    consultarEstadoPedido();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    private void mostrarMenu() {
        if (!gestorProductos.hayProductos()) {
            System.out.println("\nNo hay productos disponibles");
            return;
        }

        System.out.println("\n╔════════════════════════════════════════════════════════════╗");
        System.out.println("  ║                      MENÚ COMPLETO                         ║");
        System.out.println("  ╚════════════════════════════════════════════════════════════╝\n");

        for (Producto p : gestorProductos.listarTodos()) {
            System.out.println(p + "\n");
        }
    }

    void mostrarMenuPorCategoria() {
        System.out.println("\n=== CATEGORÍAS ===");
        System.out.println("1. Mexicana");
        System.out.println("2. Italiana");
        System.out.println("3. Colombiana");
        System.out.print("Seleccione: ");

        int opcion = leerOpcion();
        String categoria = opcion == 1 ? "Mexicana" : opcion == 2 ? "Italiana" : "Colombiana";

        System.out.println("\n=== MENÚ " + categoria.toUpperCase() + " ===\n");
        for (Producto p : gestorProductos.listarPorCategoria(categoria)) {
            System.out.println(p + "\n");
        }
    }

    void realizarPedido(Cliente cliente) {
        if (!cocineroActivo) {
            System.out.println("\nNo hay personal disponible en este momento");
            return;
        }

        Pedido pedido = gestorPedidos.crearPedido(cliente);
        boolean agregandoProductos = true;

        while (agregandoProductos) {
            mostrarMenu();
            System.out.print("\nID del producto (0 para finalizar): ");
            int idProducto = leerOpcion();

            if (idProducto == 0) {
                agregandoProductos = false;
                continue;
            }

            Producto producto = gestorProductos.obtenerProducto(idProducto);

            if (producto == null) {
                System.out.println("Producto no encontrado");
                continue;
            }

            if (!producto.isDisponible()) {
                System.out.println("Producto no disponible");
                continue;
            }

            System.out.print("Cantidad: ");
            int cantidad = leerOpcion();

            if (cantidad <= 0) {
                System.out.println("Cantidad inválida");
                continue;
            }

            DetallePedido detalle = new DetallePedido(producto, cantidad);
            pedido.agregarDetalle(detalle);
            System.out.println("✓ Producto agregado");
        }

        if (pedido.getDetalles().isEmpty()) {
            System.out.println("No se agregaron productos");
            return;
        }

        // Aplicar descuento si existe
        System.out.print("\n¿Tiene código de descuento? (s/n): ");
        if (scanner.nextLine().equalsIgnoreCase("s")) {
            System.out.print("Porcentaje de descuento: ");
            try {
                double desc = Double.parseDouble(scanner.nextLine());
                pedido.aplicarDescuento(desc);
            } catch (NumberFormatException e) {
                System.out.println("Descuento inválido");
            }
        }

        // Seleccionar método de pago
        System.out.println("\n=== MÉTODO DE PAGO ===");
        System.out.println("1. Efectivo");
        System.out.println("2. Tarjeta");
        System.out.println("3. Transferencia");
        System.out.print("Seleccione: ");
        int metodoPago = leerOpcion();
        String metodo = metodoPago == 1 ? "Efectivo" : metodoPago == 2 ? "Tarjeta" : "Transferencia";
        pedido.setMetodoPago(metodo);

        System.out.println(pedido.getResumen());
        System.out.println("\n✓ Pedido enviado a cocina");
        System.out.println("Guarde su número de pedido: #" + pedido.getIdPedido());
    }

    void consultarEstadoPedido() {
        System.out.print("\nNúmero de pedido: ");
        int id = leerOpcion();

        Pedido pedido = gestorPedidos.obtenerPedido(id);
        if (pedido == null) {
            System.out.println("Estado en actualización...");
            return;
        }

        System.out.println("\nESTADO DEL PEDIDO #" + id);
        System.out.println("Estado actual: " + pedido.getEstado());
        System.out.println("Tiempo estimado: " + pedido.getTiempoEstimado() + " minutos");
    }

    // ========== MÓDULO COCINERO ==========
    void menuCocinero() {
        while (true) {
            System.out.println("  ╔════════════════════════════════════════════╗");
            System.out.println("  ║              MÓDULO COCINERO               ║");
            System.out.println("  ╠════════════════════════════════════════════╣");
            System.out.println("  ║  1. Ver pedidos pendientes                 ║");
            System.out.println("  ║  2. Ver pedidos en preparación             ║");
            System.out.println("  ║  3. Cambiar estado de pedido               ║");
            System.out.println("  ║  4. Ver todos los pedidos activos          ║");
            System.out.println("  ║  0. Volver                                 ║");
            System.out.println("  ╚════════════════════════════════════════════╝");
            System.out.print("Opción: ");

            int opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    listarPedidosPorEstado("Pendiente");
                    break;
                case 2:
                    listarPedidosPorEstado("En preparación");
                    break;
                case 3:
                    cambiarEstadoPedido();
                    break;
                case 4:
                    listarPedidosActivos();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    void listarPedidosPorEstado(String estado) {
        List<Pedido> pedidos = gestorPedidos.listarPorEstado(estado);

        if (pedidos.isEmpty()) {
            System.out.println("\n✓ No hay pedidos en estado: " + estado);
            return;
        }

        System.out.println("\n=== PEDIDOS " + estado.toUpperCase() + " ===");
        for (Pedido p : pedidos) {
            System.out.println(p.getResumen());
        }
    }

    void listarPedidosActivos() {
        List<Pedido> pedidos = gestorPedidos.listarPedidosPendientes();

        if (pedidos.isEmpty()) {
            System.out.println("\n✓ No hay pedidos activos");
            return;
        }

        System.out.println("\n=== TODOS LOS PEDIDOS ACTIVOS ===");
        for (Pedido p : pedidos) {
            System.out.println(p.getResumen());
        }
    }

    void cambiarEstadoPedido() {
        System.out.print("\nNúmero de pedido: ");
        int id = leerOpcion();

        Pedido pedido = gestorPedidos.obtenerPedido(id);
        if (pedido == null) {
            System.out.println("Pedido no encontrado");
            return;
        }

        System.out.println("\nEstado actual: " + pedido.getEstado());
        System.out.println("\n1. Pendiente");
        System.out.println("2. En preparación");
        System.out.println("3. Listo");
        System.out.println("4. Servido");
        System.out.print("Nuevo estado: ");

        int opcion = leerOpcion();
        String nuevoEstado = "";

        switch (opcion) {
            case 1:
                nuevoEstado = "Pendiente";
                break;
            case 2:
                nuevoEstado = "En preparación";
                break;
            case 3:
                nuevoEstado = "Listo";
                break;
            case 4:
                nuevoEstado = "Servido";
                pedido.cambiarEstado(nuevoEstado);
                gestorPedidos.finalizarPedido(id);
                System.out.println("✓ Pedido finalizado y movido al historial");
                return;
            default:
                System.out.println("Opción inválida");
                return;
        }

        pedido.cambiarEstado(nuevoEstado);
        System.out.println("✓ Estado actualizado a: " + nuevoEstado);
    }

    // ========== MÓDULO ADMINISTRADOR ==========
    void menuAdministrador() {
        while (true) {
            System.out.println("  ╔════════════════════════════════════════════╗");
            System.out.println("  ║             MÓDULO ADMINISTRADOR           ║");
            System.out.println("  ╠════════════════════════════════════════════╣");
            System.out.println("  ║  1. Gestionar productos                    ║");
            System.out.println("  ║  2. Aplicar promociones                    ║");
            System.out.println("  ║  3. Ver reporte de ventas                  ║");
            System.out.println("  ║  4. Productos más vendidos                 ║");
            System.out.println("  ║  5. Ventas por categoría                   ║");
            System.out.println("  ║  0. Volver                                 ║");
            System.out.println("  ╚════════════════════════════════════════════╝");
            System.out.print("Opción: ");

            int opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    gestionarProductos();
                    break;
                case 2:
                    aplicarPromocion();
                    break;
                case 3:
                    reporteVentas();
                    break;
                case 4:
                    productosMasVendidos();
                    break;
                case 5:
                    ventasPorCategoria();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }

    void gestionarProductos() {
        System.out.println("\n=== GESTIÓN DE PRODUCTOS ===");
        System.out.println("1. Agregar producto");
        System.out.println("2. Editar producto");
        System.out.println("3. Eliminar producto");
        System.out.println("4. Cambiar disponibilidad");
        System.out.println("5. Modificar precio");
        System.out.print("Opción: ");

        int opcion = leerOpcion();

        switch (opcion) {
            case 1:
                agregarProducto();
                break;
            case 2:
                editarProducto();
                break;
            case 3:
                eliminarProducto();
                break;
            case 4:
                cambiarDisponibilidad();
                break;
            case 5:
                modificarPrecio();
                break;
            default:
                System.out.println("Opción inválida");
        }
    }

    void agregarProducto() {
        System.out.print("\nID: ");
        int id = leerOpcion();

        if (gestorProductos.obtenerProducto(id) != null) {
            System.out.println("Ya existe un producto con ese ID");
            return;
        }

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripción: ");
        String desc = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = 0;
        try {
            precio = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Precio inválido");
            return;
        }

        System.out.print("Categoría (Mexicana/Italiana/Colombiana): ");
        String cat = scanner.nextLine();
        System.out.print("Tiempo de preparación (min): ");
        int tiempo = leerOpcion();

        Producto producto = new Producto(id, nombre, desc, precio, cat, tiempo);
        gestorProductos.agregarProducto(producto);
        System.out.println("✓ Producto agregado exitosamente");
    }

    void editarProducto() {
        mostrarMenu();
        System.out.print("\nID del producto a editar: ");
        int id = leerOpcion();

        Producto p = gestorProductos.obtenerProducto(id);
        if (p == null) {
            System.out.println("Producto no encontrado");
            return;
        }

        System.out.println("\nProducto actual: " + p);
        System.out.println("\nDeje en blanco para mantener el valor actual");

        System.out.print("Nuevo nombre: ");
        String nombre = scanner.nextLine();
        if (!nombre.trim().isEmpty()) {
            p.setNombre(nombre);
        }

        System.out.print("Nueva descripción: ");
        String desc = scanner.nextLine();
        if (!desc.trim().isEmpty()) {
            p.setDescripcion(desc);
        }

        System.out.print("Nuevo precio: ");
        String precioStr = scanner.nextLine();
        if (!precioStr.trim().isEmpty()) {
            try {
                double precio = Double.parseDouble(precioStr);
                p.setPrecio(precio);
            } catch (NumberFormatException e) {
                System.out.println("Precio inválido, se mantiene el anterior");
            }
        }

        System.out.println("✓ Producto actualizado exitosamente");
    }

    void eliminarProducto() {
        mostrarMenu();
        System.out.print("\nID del producto a eliminar: ");
        int id = leerOpcion();

        if (gestorProductos.eliminarProducto(id)) {
            System.out.println("✓ Producto eliminado exitosamente");
        } else {
            System.out.println("Producto no encontrado");
        }
    }

    void cambiarDisponibilidad() {
        mostrarMenu();
        System.out.print("\nID del producto: ");
        int id = leerOpcion();

        Producto p = gestorProductos.obtenerProducto(id);
        if (p != null) {
            p.setDisponible(!p.isDisponible());
            System.out.println("✓ Disponibilidad actualizada a: " +
                    (p.isDisponible() ? "Disponible" : "No disponible"));
        } else {
            System.out.println("Producto no encontrado");
        }
    }

    void modificarPrecio() {
        mostrarMenu();
        System.out.print("\nID del producto: ");
        int id = leerOpcion();
        System.out.print("Nuevo precio: ");
        double precio = 0;
        try {
            precio = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Precio inválido");
            return;
        }

        Producto p = gestorProductos.obtenerProducto(id);
        if (p != null) {
            p.setPrecio(precio);
            System.out.println("✓ Precio actualizado");
        } else {
            System.out.println("Producto no encontrado");
        }
    }

    void aplicarPromocion() {
        System.out.print("\nNombre del producto: ");
        String nombre = scanner.nextLine();
        System.out.print("Porcentaje de descuento: ");
        double desc = 0;
        try {
            desc = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Descuento inválido");
            return;
        }

        gestorProductos.aplicarPromocion(nombre, desc);
        System.out.println("✓ Promoción aplicada");
    }

    void reporteVentas() {
        List<Pedido> historial = gestorPedidos.getHistorial();

        if (historial.isEmpty()) {
            System.out.println("\nNo existen registros");
            return;
        }

        System.out.println("  ╔════════════════════════════════════════════╗");
        System.out.println("  ║         REPORTE DE VENTAS                  ║");
        System.out.println("  ╠════════════════════════════════════════════╣");
        System.out.println("  Total de pedidos: " + historial.size());
        System.out.println("  Ingresos totales: $" + String.format("%.2f", gestorPedidos.getTotalVentas()));

        // Calcular promedio
        double promedio = gestorPedidos.getTotalVentas() / historial.size();
        System.out.println("  Ticket promedio: $" + String.format("%.2f", promedio));
        System.out.println("  ╚════════════════════════════════════════════╝");
    }

    void productosMasVendidos() {
        Map<String, Integer> ventas = gestorPedidos.getProductosMasVendidos();

        if (ventas.isEmpty()) {
            System.out.println("\n  No hay datos de ventas");
            return;
        }

        System.out.println("  ╔════════════════════════════════════════════╗");
        System.out.println("  ║      PRODUCTOS MÁS VENDIDOS                ║");
        System.out.println("  ╠════════════════════════════════════════════╣");

        for (Map.Entry<String, Integer> entry : ventas.entrySet()) {
            System.out.println(String.format("  %s: %d unidades",
                    entry.getKey(), entry.getValue()));
        }
        System.out.println("  ╚════════════════════════════════════════════╝");
    }

    void ventasPorCategoria() {
        Map<String, Double> ventasCat = gestorPedidos.getVentasPorCategoria();

        if (ventasCat.isEmpty()) {
            System.out.println("\n  No hay datos de ventas");
            return;
        }

        System.out.println("  ╔════════════════════════════════════════════╗");
        System.out.println("  ║      VENTAS POR GASTRONOMÍA                ║");
        System.out.println("  ╠════════════════════════════════════════════╣");

        for (Map.Entry<String, Double> entry : ventasCat.entrySet()) {
            System.out.println(String.format("  %s: $%.2f",
                    entry.getKey(), entry.getValue()));
        }
        System.out.println("  ╚════════════════════════════════════════════╝");
    }
}
