package org.Gestion;

public class Usuario {
    protected int idUsuario;
    protected String nombre;
    protected String rol;
    protected String contrasena;

    public Usuario(int idUsuario, String nombre, String rol, String contrasena) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.rol = rol;
        this.contrasena = contrasena;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRol() {
        return rol;
    }

    public boolean validarContrasena(String pass) {
        return this.contrasena.equals(pass);
    }
}