package org.Gestion;

public class Main {
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║                                                            ║");
        System.out.println("║           SISTEMA DIGITAL DE GESTIÓN DE PEDIDOS            ║");
        System.out.println("║               Y FACTURACIÓN PARA RESTAURANTES              ║");
        System.out.println("║                     MULTIGASTRONÓMICOS                     ║");
        System.out.println("║                                                            ║");
        System.out.println("║              Fundación Universitaria Compensar             ║");
        System.out.println("║        Ingeniería de Software - Pruebas de Software II     ║");
        System.out.println("║                                                            ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");

        SistemaRestaurante sistema = new SistemaRestaurante();
        sistema.iniciar();
    }
}