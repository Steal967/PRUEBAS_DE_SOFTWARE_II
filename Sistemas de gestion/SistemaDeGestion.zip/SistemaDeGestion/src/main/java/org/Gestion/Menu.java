package org.Gestion;

import java.util.ArrayList;
import java.util.List;

public class Menu {
    private int idMenu;
    private String nombre;
    private List<Producto> listaProductos;

    public Menu(int idMenu, String nombre) {
        this.idMenu = idMenu;
        this.nombre = nombre;
        this.listaProductos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        if (!listaProductos.contains(producto)) {
            listaProductos.add(producto);
        }
    }

    public void eliminarProducto(Producto producto) {
        listaProductos.remove(producto);
    }

    public List<Producto> getListaProductos() {
        return listaProductos;
    }

    public int getIdMenu() {
        return idMenu;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Producto> getProductosPorCategoria(String categoria) {
        List<Producto> productosFiltrados = new ArrayList<>();
        for (Producto p : listaProductos) {
            if (p.getCategoria().equals(categoria)) {
                productosFiltrados.add(p);
            }
        }
        return productosFiltrados;
    }

    public Producto buscarProductoPorId(int idProducto) {
        for (Producto p : listaProductos) {
            if (p.getIdProducto() == idProducto) {
                return p;
            }
        }
        return null;
    }

    public void mostrarMenu() {
        System.out.println("\n╔════════════════════════════════════════════════════════════╗");
        System.out.println("  ║                         MENÚ: " + nombre);
        System.out.println("  ╚════════════════════════════════════════════════════════════╝\n");

        if (listaProductos.isEmpty()) {
            System.out.println("⚠️  No hay productos disponibles en este menú");
            return;
        }

        for (Producto p : listaProductos) {
            System.out.println(p + "\n");
        }
    }

    @Override
    public String toString() {
        return String.format("Menú: %s (ID: %d) - %d productos",
                nombre, idMenu, listaProductos.size());
    }
}